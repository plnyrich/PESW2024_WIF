var searchData=
[
  ['ipv4_5fmax_5fprefix_5flength',['IPV4_MAX_PREFIX_LENGTH',['../classWIF_1_1IpPrefix.html#a9b02b0d56900556bcec1b530cb9725d4',1,'WIF::IpPrefix']]],
  ['ipv6_5fmax_5fprefix_5flength',['IPV6_MAX_PREFIX_LENGTH',['../classWIF_1_1IpPrefix.html#a69affce92b154d15948b2e412a21e4be',1,'WIF::IpPrefix']]]
];
