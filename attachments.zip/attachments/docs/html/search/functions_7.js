var searchData=
[
  ['markmodelasobsolete',['markModelAsObsolete',['../classWIF_1_1AlfClassifier.html#a7d5b85fc381389708cfe3e4564923e4b',1,'WIF::AlfClassifier']]],
  ['match',['match',['../classWIF_1_1RegexPattern.html#a858c68b09f53843a5f9a36058c14be55',1,'WIF::RegexPattern::match()'],['../classWIF_1_1IpPrefix.html#a6f779ee9e28b72fff8901cb500b0940c',1,'WIF::IpPrefix::match()']]]
];
