var searchData=
[
  ['classifier',['Classifier',['../classWIF_1_1Classifier.html',1,'WIF']]],
  ['clfresult',['ClfResult',['../classWIF_1_1ClfResult.html',1,'WIF']]],
  ['combinator',['Combinator',['../classWIF_1_1Combinator.html',1,'WIF']]]
];
