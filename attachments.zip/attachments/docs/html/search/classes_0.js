var searchData=
[
  ['alfclassifier',['AlfClassifier',['../classWIF_1_1AlfClassifier.html',1,'WIF']]],
  ['averagecombinator',['AverageCombinator',['../classWIF_1_1AverageCombinator.html',1,'WIF']]]
];
