var searchData=
[
  ['regexclassifier',['RegexClassifier',['../classWIF_1_1RegexClassifier.html#af0b57321c003be68f283f1a59c0f11e7',1,'WIF::RegexClassifier']]],
  ['regexpattern',['RegexPattern',['../classWIF_1_1RegexPattern.html#a3344511e03800a092d134813191b3b2c',1,'WIF::RegexPattern']]],
  ['reloadmodel',['reloadModel',['../classWIF_1_1ScikitMlWrapper.html#ace6a0f0bc95533191d0852497977b6d4',1,'WIF::ScikitMlWrapper']]],
  ['reloadmodelfromdisk',['reloadModelFromDisk',['../classWIF_1_1ScikitMlClassifier.html#ac1741fa06d7201db10f5e769aa93598e',1,'WIF::ScikitMlClassifier']]],
  ['report',['report',['../classWIF_1_1Reporter.html#a82d09c0ba6a509bdbfc873c4d1c1c4ba',1,'WIF::Reporter::report()'],['../classWIF_1_1UnirecReporter.html#a7c812d2eec6987822ee7f951cc9da029',1,'WIF::UnirecReporter::report()']]]
];
