var searchData=
[
  ['unirecreporter',['UnirecReporter',['../classWIF_1_1UnirecReporter.html',1,'WIF']]]
];
