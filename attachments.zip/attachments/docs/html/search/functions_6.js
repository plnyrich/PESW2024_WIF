var searchData=
[
  ['ipaddress',['IpAddress',['../classWIF_1_1IpAddress.html#ae4e81321e8b9381859cfcc229435efa2',1,'WIF::IpAddress::IpAddress()'],['../classWIF_1_1IpAddress.html#adb4488d1d4e1851f86bac50d50d85a4a',1,'WIF::IpAddress::IpAddress(uint32_t data)'],['../classWIF_1_1IpAddress.html#a3a0c74422743153cc43eec6b736e2a54',1,'WIF::IpAddress::IpAddress(const uint8_t *bytes, IpVersion ipVersion, bool isLittleEndian=true)'],['../classWIF_1_1IpAddress.html#aedfc004259c8e660db2bd32d324daeed',1,'WIF::IpAddress::IpAddress(const std::string &amp;str)']]],
  ['ipprefix',['IpPrefix',['../classWIF_1_1IpPrefix.html#ae0429a76e67341fa5552081d93cdb668',1,'WIF::IpPrefix::IpPrefix(const IpAddress &amp;address)'],['../classWIF_1_1IpPrefix.html#a856b19ad48ea5a62677d72040bcf995c',1,'WIF::IpPrefix::IpPrefix(const std::string &amp;addressStr, size_t prefixLength)'],['../classWIF_1_1IpPrefix.html#a4315bc2463d37e5c717f49312e0fb93d',1,'WIF::IpPrefix::IpPrefix(const IpAddress &amp;address, size_t prefixLength)']]],
  ['ipprefixclassifier',['IpPrefixClassifier',['../classWIF_1_1IpPrefixClassifier.html#a030dcc087723e516cef550fc9097dc67',1,'WIF::IpPrefixClassifier::IpPrefixClassifier()=default'],['../classWIF_1_1IpPrefixClassifier.html#a339507331d08b85ed22139148b3b910c',1,'WIF::IpPrefixClassifier::IpPrefixClassifier(const std::vector&lt; IpPrefix &gt; &amp;blocklist)']]],
  ['ischangedetected',['isChangeDetected',['../classWIF_1_1FileModificationChecker.html#acb9a2073ac8757a09db4062f52fa2aa4',1,'WIF::FileModificationChecker']]],
  ['isipv4',['isIPv4',['../classWIF_1_1IpAddress.html#a770e7ba0bfd68dea7b00fc83a58bca20',1,'WIF::IpAddress']]],
  ['isipv6',['isIPv6',['../classWIF_1_1IpAddress.html#ae8e2e93dcd69000c2d61a0fd2a7f3ce3',1,'WIF::IpAddress']]]
];
