var searchData=
[
  ['alfclassifier',['AlfClassifier',['../classWIF_1_1AlfClassifier.html#a5d89245641ec8d273d28045af246196b',1,'WIF::AlfClassifier']]]
];
