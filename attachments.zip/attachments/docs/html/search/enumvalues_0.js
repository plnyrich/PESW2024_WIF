var searchData=
[
  ['all',['ALL',['../classWIF_1_1RegexPattern.html#a276fa20a0a607aab39145592b91e3b17a5fb1f955b45e38e31789286a1790398d',1,'WIF::RegexPattern']]],
  ['any',['ANY',['../classWIF_1_1RegexPattern.html#a276fa20a0a607aab39145592b91e3b17a8e1bde3c3d303163521522cf1d62f21f',1,'WIF::RegexPattern']]]
];
