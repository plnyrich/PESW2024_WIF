var searchData=
[
  ['regexclassifier',['RegexClassifier',['../classWIF_1_1RegexClassifier.html',1,'WIF::RegexClassifier'],['../classWIF_1_1RegexClassifier.html#af0b57321c003be68f283f1a59c0f11e7',1,'WIF::RegexClassifier::RegexClassifier()']]],
  ['regexclassifier_2ecpp',['regexClassifier.cpp',['../regexClassifier_8cpp.html',1,'']]],
  ['regexclassifier_2ehpp',['regexClassifier.hpp',['../regexClassifier_8hpp.html',1,'']]],
  ['regexpattern',['RegexPattern',['../classWIF_1_1RegexPattern.html',1,'WIF::RegexPattern'],['../classWIF_1_1RegexPattern.html#a3344511e03800a092d134813191b3b2c',1,'WIF::RegexPattern::RegexPattern()']]],
  ['regexpattern_2ecpp',['regexPattern.cpp',['../regexPattern_8cpp.html',1,'']]],
  ['regexpattern_2ehpp',['regexPattern.hpp',['../regexPattern_8hpp.html',1,'']]],
  ['reloadmodel',['reloadModel',['../classWIF_1_1ScikitMlWrapper.html#ace6a0f0bc95533191d0852497977b6d4',1,'WIF::ScikitMlWrapper']]],
  ['reloadmodelfromdisk',['reloadModelFromDisk',['../classWIF_1_1ScikitMlClassifier.html#ac1741fa06d7201db10f5e769aa93598e',1,'WIF::ScikitMlClassifier']]],
  ['report',['report',['../classWIF_1_1Reporter.html#a82d09c0ba6a509bdbfc873c4d1c1c4ba',1,'WIF::Reporter::report()'],['../classWIF_1_1UnirecReporter.html#a7c812d2eec6987822ee7f951cc9da029',1,'WIF::UnirecReporter::report()']]],
  ['reporter',['Reporter',['../classWIF_1_1Reporter.html',1,'WIF']]],
  ['reporter_2ehpp',['reporter.hpp',['../reporter_8hpp.html',1,'']]]
];
