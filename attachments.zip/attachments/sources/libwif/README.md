WIF (Weak Indication Framework)
