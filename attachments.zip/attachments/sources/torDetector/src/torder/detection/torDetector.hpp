
/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Tor detector interface
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "torder/settings/wifTable.hpp"
#include <fstream>
#include <mutex>
#include <unirec++/unirec.hpp>
#include <wif/classifiers/ipPrefixClassifier.hpp>
#include <wif/filesystem/fileModificationChecker.hpp>
#include <wif/utils/timer.hpp>

namespace TorDer {

class TorDetector {
	class TorTimerCallback : public WIF::TimerCallback {
	public:
		TorTimerCallback(TorDetector& classifier)
			: m_classifier(classifier)
			, m_checker(classifier.torRelaysFilePath())
		{
		}

		void onTick() override;

	private:
		TorDetector& m_classifier;
		WIF::FileModificationChecker m_checker;
	};

public:
	TorDetector(const std::string& torRelaysSrcFile, unsigned tickIntervalInSeconds);

	void update(const WIF::FlowFeatures& flowData);

	bool result() const noexcept { return m_result; }
	int8_t direction() const noexcept { return m_direction; }

	void updateTorRelays();
	const std::string& torRelaysFilePath() const noexcept { return m_torRelaysSrcFile; }

private:
	constexpr static int8_t TOR_RELAY_IN_DST_IP = 1;
	constexpr static int8_t TOR_RELAY_IN_SRC_IP = -1;
	constexpr static int8_t TOR_RELAY_NOWHERE = 0;

	std::vector<WIF::IpPrefix> loadTorRelaysFile(const std::string& torRelaysSrcFile) const;

	bool m_result = false;
	int8_t m_direction = TOR_RELAY_NOWHERE;
	std::string m_torRelaysSrcFile;
	WIF::FlowFeatures m_features;
	WIF::IpPrefixClassifier m_ipPrefixClf;

	std::mutex m_mutex;
	WIF::Timer m_timer;
};

} // namespace TorDer
