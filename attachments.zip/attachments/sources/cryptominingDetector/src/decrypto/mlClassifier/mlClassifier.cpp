/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief ML classifier implementation
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "decrypto/mlClassifier/mlClassifier.hpp"

using namespace Nemea;
using namespace WIF;

namespace DeCrypto {

const std::string REPORTER_UNIREC_TEMPLATE
	= "ipaddr SRC_IP,ipaddr DST_IP,uint16 SRC_PORT,uint16 DST_PORT,double FEATURE_BYTES,double "
	  "FEATURE_BYTES_REV,double FEATURE_PACKETS,double "
	  "FEATURE_PACKETS_REV,double "
	  "FEATURE_SENT,double FEATURE_RECV,double FEATURE_AVG_PKT_INTERVAL,double "
	  "FEATURE_OVERALL_DURATION,double "
	  "FEATURE_AVG_PKT_SIZE,double FEATURE_PSH_RATIO,double FEATURE_MIN_PKT_LEN,double "
	  "FEATURE_DATA_SYMMETRY,uint64 LAST_MODEL_LOAD_TIME,double* "
	  "PREDICTED_PROBAS";

MlClassifier::MlClassifier(
	const std::string& modelPath,
	const std::string& bridgePath,
	bool useAlf,
	UnirecOutputInterface& reporterIfc)
{
	reporterIfc.changeTemplate(REPORTER_UNIREC_TEMPLATE);
	m_unirecReporter = std::make_unique<WIF::UnirecReporter>(reporterIfc);

	m_mlClassifier = std::make_unique<ScikitMlClassifier>(bridgePath, modelPath);
	m_selectedClassifier = m_mlClassifier.get();

	if (useAlf) {
		m_alfClassifier = std::make_unique<AlfClassifier>(*m_mlClassifier, *m_unirecReporter, 30);
		m_selectedClassifier = m_alfClassifier.get();
	}
}

void MlClassifier::setAlfSources(const std::vector<FeatureID>& featureIDs)
{
	m_alfClassifier->setFeatureSourceIDs(featureIDs);
}

void MlClassifier::setSources(const std::vector<FeatureID>& featureIDs)
{
	m_mlClassifier->setFeatureSourceIDs(featureIDs);
}

void MlClassifier::updateUnirecIDs()
{
	std::vector<ur_field_id_t> fieldIDs;
	fieldIDs.emplace_back(ur_get_id_by_name("SRC_IP"));
	fieldIDs.emplace_back(ur_get_id_by_name("DST_IP"));
	fieldIDs.emplace_back(ur_get_id_by_name("SRC_PORT"));
	fieldIDs.emplace_back(ur_get_id_by_name("DST_PORT"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_BYTES"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_BYTES_REV"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_PACKETS"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_PACKETS_REV"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_SENT"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_RECV"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_AVG_PKT_INTERVAL"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_OVERALL_DURATION"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_AVG_PKT_SIZE"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_PSH_RATIO"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_MIN_PKT_LEN"));
	fieldIDs.emplace_back(ur_get_id_by_name("FEATURE_DATA_SYMMETRY"));
	fieldIDs.emplace_back(ur_get_id_by_name("LAST_MODEL_LOAD_TIME"));
	fieldIDs.emplace_back(ur_get_id_by_name("PREDICTED_PROBAS"));
	m_unirecReporter->updateUnirecFieldIDs(fieldIDs);
}

std::vector<WIF::ClfResult> MlClassifier::classify(const std::vector<FlowFeatures>& flows)
{
	return m_selectedClassifier->classify(flows);
}

} // namespace DeCrypto
