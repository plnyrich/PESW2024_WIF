/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief IP Ranges Loader interface
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "tunder/utils/string.hpp"

#include <fstream>
#include <iostream>
#include <vector>
#include <wif/utils/ipPrefix.hpp>

namespace TunDer {

/**
 * @brief Observed IP ranges.
 * Every IP address from each defined range is observed, and alert is sent when suspicious behavior
 * is detected.
 * @return std::vector<WIF::IpRange>
 */

class IpRangesLoader {
public:
	IpRangesLoader(const std::string& sourceFile);

	const std::vector<WIF::IpPrefix>& loadedIpRanges() { return m_loadedIpRanges; }

private:
	void readFile(const std::string& sourceFilePath);
	bool isEmptyLine(const std::string& line) const;
	bool isComment(const std::string& line) const;
	bool hasOnePart(const std::vector<std::string>& parts);
	bool hasTwoParts(const std::vector<std::string>& parts);
	void tryToParseIpRange(std::vector<std::string>& parts);
	void tryToParseIpPrefix(std::vector<std::string>& parts);
	std::vector<std::string> splitLineByComma(const std::string& line) const;

	std::vector<WIF::IpPrefix> m_loadedIpRanges;
};

} // namespace TunDer
