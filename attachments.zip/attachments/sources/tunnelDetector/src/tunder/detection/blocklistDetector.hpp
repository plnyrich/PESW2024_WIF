/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Blocklist detector class
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "tunder/detection/detector.hpp"
#include "tunder/settings/ipRangesLoader.hpp"
#include "tunder/store/counterStore.hpp"

#include <fstream>
#include <iostream>
#include <mutex>
#include <wif/classifiers/ipPrefixClassifier.hpp>
#include <wif/filesystem/fileModificationChecker.hpp>
#include <wif/utils/timer.hpp>

namespace TunDer {

class BlocklistDetector : public Detector {
	class BlocklistUpdater : public WIF::TimerCallback {
	public:
		BlocklistUpdater(BlocklistDetector& classifier)
			: m_classifier(classifier)
			, m_checker(classifier.blocklistFile())
		{
		}

		void onTick() override
		{
			if (m_checker.isChangeDetected()) {
				m_classifier.updateBlocklist();
			}
		}

	private:
		BlocklistDetector& m_classifier;
		WIF::FileModificationChecker m_checker;
	};

public:
	BlocklistDetector(
		const std::string& blocklistFile,
		unsigned tickInterval,
		unsigned threshold,
		uint64_t storeSize,
		ur_field_id_t resultId,
		ur_field_id_t explanationId)
		: Detector(explanationId, resultId)
		, m_threshold(threshold)
		, m_store(storeSize)
		, m_blocklistFile(blocklistFile)
		, m_timer(tickInterval, std::make_unique<BlocklistUpdater>(*this))
	{
		updateBlocklist();
		m_timer.start();
	}

	DetectorID detectorID() const noexcept override { return DetectorID::BLOCKLIST; }

	const std::string& blocklistFile() const { return m_blocklistFile; }

	void updateBlocklist()
	{
		IpRangesLoader blocklistLoader(m_blocklistFile);
		std::cout << "[Blocklist Detector] New blocklist has "
				  << blocklistLoader.loadedIpRanges().size() << " IP prefixes" << std::endl;
		std::lock_guard<std::mutex> lock(m_mutex);
		m_classifier.updateBlocklist(blocklistLoader.loadedIpRanges());
	}

	void update(IpKey key, const WIF::FlowFeatures& data) override
	{
		auto storeIndex = m_store.ensureKeyInStore(key);
		std::lock_guard<std::mutex> lock(m_mutex);
		double classificationResult = m_classifier.classify(data).get<double>();
		if (classificationResult > 0) {
			m_store.increment(storeIndex);
		}
	}

	DetectionResult result(IpKey key) const override
	{
		auto storeIndex = m_store.keyToIndex(key);
		return m_store.get(storeIndex) >= m_threshold;
	}

	std::string explain(IpKey key) const override
	{
		auto storeIndex = m_store.keyToIndex(key);
		return std::to_string(m_store.get(storeIndex)) + "x BLOCKLISTED FLOWS";
	}

	void reset() override { m_store.clear(); }

	void setSourceFeatureIDs(const std::vector<WIF::FeatureID>& featureIDs) override
	{
		m_classifier.setFeatureSourceIDs(featureIDs);
	}

protected:
	unsigned m_threshold;
	CounterStore m_store;
	std::string m_blocklistFile;
	WIF::IpPrefixClassifier m_classifier;
	std::mutex m_mutex;
	WIF::Timer m_timer;
};

} // namespace TunDer
