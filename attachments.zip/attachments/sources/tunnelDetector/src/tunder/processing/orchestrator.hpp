/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Orchestrator interface
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "tunder/detection/blocklistDetector.hpp"
#include "tunder/detection/confLevelDetector.hpp"
#include "tunder/detection/portDetector.hpp"
#include "tunder/detection/torDetector.hpp"
#include "tunder/rules/andRule.hpp"
#include "tunder/rules/basicRule.hpp"
#include "tunder/rules/orRule.hpp"
#include "tunder/settings/config.hpp"
#include "tunder/settings/ipRangesLoader.hpp"
#include "tunder/settings/unirecIDTable.hpp"
#include "tunder/utils/discardController.hpp"
#include "tunder/utils/ipConvertor.hpp"
#include "tunder/utils/ipHashMap.hpp"

#include <memory>
#include <unirec++/unirec.hpp>
#include <unirec/unirec.h>
#include <vector>
#include <wif/storage/flowFeatures.hpp>

namespace TunDer {

class Orchestrator {
	using OutputInterface = Nemea::UnirecOutputInterface;

public:
	Orchestrator(const Config& config, UnirecIDTable& unirecIDTable, OutputInterface& outputIfc);

	bool accept(const WIF::IpAddress& srcIp, const WIF::IpAddress& dstIp);
	bool isReversed() const noexcept;

	void onFlowReceived(const WIF::FlowFeatures& data);
	void onTimeIntervalExpired();
	void onEnd();

private:
	inline void initWindow(uint64_t currentFlowTime);
	inline void setNextWindowEndTime(uint64_t currentFlowTime);
	inline bool windowSet() const noexcept;
	inline bool shouldExport(uint64_t currentFlowTime) const noexcept;

	inline void handleExport(uint64_t currentFlowTime);
	inline void performDetection(IpKey key);
	inline bool checkRule(Rule& rule, IpKey key);
	inline void exportMatchedRuleInfo(Rule& rule, IpKey key);
	inline void resetDetectors();

	inline IpKey calculateIpKey(const WIF::IpAddress& ip) const;

	void registerDetectors();
	void registerRules();

	const Config& m_config;

	bool m_windowSet = false;
	uint64_t m_nextWindowEndTime;
	uint32_t m_windowSize;

	std::vector<WIF::IpPrefix> m_observedRanges;
	IpHashMap m_ipHashMap;
	DiscardController m_discardController;

	bool m_isReversed = false;

	UnirecIDTable& m_unirecIDTable;
	OutputInterface& m_outIfc;

	std::vector<std::unique_ptr<Detector>> m_detectors;
	std::vector<std::unique_ptr<Rule>> m_rules;
};

} // namespace TunDer
