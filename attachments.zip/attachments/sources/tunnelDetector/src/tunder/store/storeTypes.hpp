/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Store type definitions
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "tunder/utils/flatHashMap.hpp"
#include "tunder/utils/xxhash.hpp"

#include <cstddef>
#include <vector>

#include <iostream>

namespace TunDer {

using IpKey = XXH64_hash_t;

class Store {
public:
	Store(uint64_t maxSize)
		: m_maxSize(maxSize)
	{
		m_keyMap.reserve(maxSize);
	}

	bool isFull() const noexcept { return m_keyMap.size() == m_maxSize; }

	void clear()
	{
		m_keyMap.clear();
		m_lastIndex = 0;
	}

	unsigned keyToIndex(IpKey key) const
	{
		auto iterator = m_keyMap.find(key);
		return (*iterator).second;
	}

	unsigned ensureKeyInStore(IpKey key)
	{
		auto iterator = m_keyMap.find(key);
		if (iterator != m_keyMap.cend()) {
			// Key is in the map
			return (*iterator).second;
		}

		// Key was not found
		if (isFull()) {
			// We cannot insert a new key
			throw std::runtime_error("BinaryStore::ensureKeyInStore(): Store is full!");
		}

		std::pair<IpKey, unsigned> dummy;
		auto [newKeyIterator, status] = m_keyMap.insert_no_grow(dummy, key, m_lastIndex++);

		return (*newKeyIterator).second;
	}

private:
	unsigned m_lastIndex = 0;
	uint64_t m_maxSize;
	ska::flat_hash_map<IpKey, unsigned> m_keyMap;
};

} // namespace TunDer
