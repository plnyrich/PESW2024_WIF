/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Counter store
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "tunder/store/storeTypes.hpp"

namespace TunDer {

class CounterStore : public Store {
public:
	CounterStore(uint64_t maxSize)
		: Store(maxSize)
	{
		m_dataStore.resize(maxSize);
	}

	size_t size() const noexcept { return m_dataStore.size(); }

	void clear()
	{
		Store::clear();
		std::fill(m_dataStore.begin(), m_dataStore.end(), 0);
	}

	unsigned get(unsigned index) const { return m_dataStore[index]; }

	void increment(unsigned index) { m_dataStore[index] += 1; }

private:
	std::vector<uint16_t> m_dataStore;
};

} // namespace TunDer
