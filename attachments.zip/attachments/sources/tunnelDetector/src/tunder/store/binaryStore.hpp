/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Binary store
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "tunder/store/storeTypes.hpp"

namespace TunDer {

class BinaryStore : public Store {
public:
	BinaryStore(uint64_t maxSize)
		: Store(maxSize)
	{
		m_dataStore.resize(maxSize);
	}

	size_t size() const noexcept { return m_dataStore.size(); }

	void clear()
	{
		Store::clear();
		std::fill(m_dataStore.begin(), m_dataStore.end(), 0);
	}

	void setPositive(unsigned index) { m_dataStore[index] = 1; }

	void setNegative(unsigned index) { m_dataStore[index] = 0; }

	bool isPositive(unsigned index) const { return m_dataStore[index] == 1; }

	bool isNegative(unsigned index) const { return m_dataStore[index] == 0; }

private:
	std::vector<uint8_t> m_dataStore;
};

} // namespace TunDer
