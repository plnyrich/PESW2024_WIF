/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief IP Convertor
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <unirec++/ipAddress.hpp>
#include <wif/storage/ipAddress.hpp>

#pragma once

namespace TunDer::Utils {

inline WIF::IpAddress toWifIp(const Nemea::IpAddress& ip)
{
	return WIF::IpAddress(ip.ip.bytes, WIF::IpAddress::IpVersion::V6, true);
}

inline Nemea::IpAddress toNemeaIp(const WIF::IpAddress& ip)
{
	Nemea::IpAddress newIp;
	std::memcpy(&newIp.ip.bytes, ip.data(), 16);
	return newIp;
}

} // namespace TunDer::Utils
