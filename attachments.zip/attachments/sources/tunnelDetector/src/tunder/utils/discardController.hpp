/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Discard controller
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <ctime>
#include <ostream>
#include <vector>
#include <wif/utils/ipPrefix.hpp>

namespace TunDer {

class DiscardController {
public:
	DiscardController() {}

	void resize(size_t size) { m_discardedCounts.resize(size); }

	void setCurrentIndex(unsigned currentIndex) { m_currentIndex = currentIndex; }

	void flowDiscarded() { ++m_discardedCounts[m_currentIndex]; }

	void dumpStatistics(std::ostream& os, const std::vector<WIF::IpPrefix>& ranges) const
	{
		printJsonStart(os);
		bool arrayStart = true;
		for (unsigned index = 0; index < m_discardedCounts.size(); ++index) {
			if (m_discardedCounts[index] > 0) {
				if (arrayStart) {
					arrayStart = false;
				} else {
					os << ",";
				}
				printStatistic(os, ranges[index], m_discardedCounts[index]);
			}
		}
		printJsonEnd(os);
	}

	void reset() { std::fill(m_discardedCounts.begin(), m_discardedCounts.end(), 0); }

private:
	void printJsonStart(std::ostream& os) const
	{
		os << "{";
		os << "\"timestamp\":";
		os << "\"";
		printISOTimestamp(os);
		os << "\",";
		os << "\"discardStatistics\":[";
	}

	void printJsonEnd(std::ostream& os) const { os << "]}" << std::endl; }

	void printStatistic(std::ostream& os, const WIF::IpPrefix& range, unsigned long count) const
	{
		os << "{";
		os << "\"" << range.getPrefix().toString() << "/" << range.prefixLength() << "\"";
		os << ":";
		os << count;
		os << "}";
	}

	void printISOTimestamp(std::ostream& os) const
	{
		std::time_t time = std::time({});
		char timeString[std::size("yyyy-mm-ddThh:mm:ssZ")];
		std::strftime(std::data(timeString), std::size(timeString), "%FT%TZ", std::gmtime(&time));
		os << timeString;
	}

	unsigned m_currentIndex = -1;
	std::vector<unsigned long> m_discardedCounts;
};

} // namespace TunDer
