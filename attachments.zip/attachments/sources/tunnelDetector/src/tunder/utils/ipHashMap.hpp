/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief IP hash map
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include "tunder/utils/flatHashMap.hpp"
#include "tunder/utils/xxhash.hpp"

#include <wif/storage/ipAddress.hpp>

namespace TunDer {

class IpHashMap {
public:
	IpHashMap(uint64_t maxPairCount)
		: m_maxPairCount(maxPairCount)
	{
		m_map.reserve(m_maxPairCount);
	}

	bool isFull() const noexcept { return m_map.size() == m_maxPairCount; }

	size_t size() const noexcept { return m_map.size(); }

	void clear() { m_map.clear(); }

	bool contains(IpKey key) const { return m_map.find(key) != m_map.cend(); }

	bool registerIpAddress(IpKey key, const WIF::IpAddress& ipAddress)
	{
		if (m_map.find(key) != m_map.cend()) {
			// Key is in the map
			return true;
		}

		if (isFull()) {
			return false;
		}

		std::pair<IpKey, WIF::IpAddress> dummy;
		auto [_, status] = m_map.insert_no_grow(dummy, key, ipAddress);
		return status == ska::INSERTED;
	}

	WIF::IpAddress findIpAddress(IpKey key) const
	{
		auto iterator = m_map.find(key);
		if (iterator != m_map.cend()) {
			return (*iterator).second;
		} else {
			return WIF::IpAddress();
		}
	}

	ska::flat_hash_map<IpKey, WIF::IpAddress>::const_iterator cbegin() const
	{
		return m_map.cbegin();
	}

	ska::flat_hash_map<IpKey, WIF::IpAddress>::const_iterator cend() const { return m_map.cend(); }

private:
	uint64_t m_maxPairCount;
	ska::flat_hash_map<IpKey, WIF::IpAddress> m_map;
};

} // namespace TunDer
