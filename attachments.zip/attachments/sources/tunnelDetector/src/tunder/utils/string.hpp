/**
 * @file
 * @author Richard Plny <plnyrich@fit.cvut.cz>
 * @brief Strings interface
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#pragma once

#include <string>
#include <vector>

namespace Tunder {

class Strings {
public:
	static std::vector<std::string>
	splitStringBy(const std::string& str, const std::string& delimiter)
	{
		std::vector<std::string> result;
		size_t startIndex = 0;

		for (size_t found = str.find(delimiter); found != std::string::npos;
			 found = str.find(delimiter, startIndex)) {
			result.emplace_back(str.begin() + startIndex, str.begin() + found);
			startIndex = found + delimiter.size();
		}

		if (startIndex != str.size()) {
			result.emplace_back(str.begin() + startIndex, str.end());
		}

		return result;
	}
};

} // namespace Tunder
